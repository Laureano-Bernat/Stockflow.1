# StockFlow - Sistema de Control de Inventario y Gestión de Stock

Aplicación web desarrollada en **Java 17** y **Spring Boot** para la administración centralizada de inventarios, trazabilidad transaccional de stock y alertas de reposición.

## 🚀 Tecnologías utilizadas
* **Backend:** Java 17, Spring Boot 3 (Spring Web, Spring Data JPA, Jakarta Validation, Lombok).
* **Frontend:** HTML5, CSS3 (Bootstrap 5), Thymeleaf.
* **Persistencia:** Hibernate JPA / H2 Database (desarrollo).
* **Arquitectura:** Modelo-Vista-Controlador (MVC) en capas con Rich Domain Model.

## 🛠️ Cómo ejecutar el proyecto
1. Descomprimir el archivo ZIP.
2. Abrir la carpeta `stockflow` en tu IDE preferido (IntelliJ IDEA, VS Code, Eclipse).
3. Ejecutar `StockFlowApplication.java` o correr `mvn spring-boot:run`.
4. Abrir la aplicación en el navegador en `http://localhost:8080/productos`.