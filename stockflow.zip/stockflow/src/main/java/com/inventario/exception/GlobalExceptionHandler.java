package com.inventario.exception;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(StockInsuficienteException.class)
    public String handleStockInsuficiente(StockInsuficienteException ex, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        return "redirect:/movimientos/nuevo";
    }

    @ExceptionHandler(EntityNotFoundException.class)
    public String handleEntityNotFound(EntityNotFoundException ex, Model model) {
        model.addAttribute("errorCode", "404 - RECURSO NO ENCONTRADO");
        model.addAttribute("errorMessage", ex.getMessage());
        return "error/error_page";
    }

    @ExceptionHandler(Exception.class)
    public String handleGenericException(Exception ex, Model model) {
        model.addAttribute("errorCode", "500 - ERROR INTERNO DEL SERVIDOR");
        model.addAttribute("errorMessage", ex.getMessage());
        return "error/error_page";
    }
}