package com.inventario.controller;

import com.inventario.model.Producto;
import com.inventario.service.CategoriaService;
import com.inventario.service.ProductoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/productos")
@RequiredArgsConstructor
public class ProductoController {

    private final ProductoService productoService;
    private final CategoriaService categoriaService;

    @GetMapping
    public String listarProductos(
            @RequestParam(required = false) String query,
            @RequestParam(required = false) Long categoriaId,
            Model model) {
        model.addAttribute("productos", productoService.filtrarProductos(query, categoriaId));
        model.addAttribute("categorias", categoriaService.obtenerTodasActivas());
        model.addAttribute("query", query);
        model.addAttribute("categoriaSeleccionada", categoriaId);
        return "productos/lista";
    }

    @GetMapping("/nuevo")
    public String mostrarFormularioCreacion(Model model) {
        model.addAttribute("producto", new Producto());
        model.addAttribute("categorias", categoriaService.obtenerTodasActivas());
        return "productos/form";
    }

    @PostMapping("/guardar")
    public String guardarProducto(
            @Valid @ModelAttribute("producto") Producto producto,
            BindingResult result,
            Model model,
            RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            model.addAttribute("categorias", categoriaService.obtenerTodasActivas());
            return "productos/form";
        }
        productoService.guardar(producto);
        redirectAttributes.addFlashAttribute("successMessage", "Producto guardado correctamente.");
        return "redirect:/productos";
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicion(@PathVariable Long id, Model model) {
        model.addAttribute("producto", productoService.obtenerPorId(id));
        model.addAttribute("categorias", categoriaService.obtenerTodasActivas());
        return "productos/form";
    }

    @PostMapping("/eliminar/{id}")
    public String bajaLogicaProducto(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        productoService.bajaLogica(id);
        redirectAttributes.addFlashAttribute("successMessage", "Producto desactivado del catálogo.");
        return "redirect:/productos";
    }
}