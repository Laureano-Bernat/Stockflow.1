package com.inventario.controller;

import com.inventario.model.TipoMovimiento;
import com.inventario.service.MovimientoStockService;
import com.inventario.service.ProductoService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/movimientos")
@RequiredArgsConstructor
public class MovimientoStockController {

    private final MovimientoStockService movimientoService;
    private final ProductoService productoService;

    @GetMapping
    public String listarMovimientos(Model model) {
        model.addAttribute("movimientos", movimientoService.obtenerHistorial());
        return "movimientos/lista";
    }

    @GetMapping("/nuevo")
    public String mostrarFormularioMovimiento(Model model) {
        model.addAttribute("productos", productoService.obtenerTodosActivos());
        model.addAttribute("tipos", TipoMovimiento.values());
        return "movimientos/form";
    }

    @PostMapping("/guardar")
    public String registrarMovimiento(
            @RequestParam Long productoId,
            @RequestParam TipoMovimiento tipo,
            @RequestParam Integer cantidad,
            @RequestParam(required = false) String motivo,
            RedirectAttributes redirectAttributes) {
        movimientoService.registrarMovimiento(productoId, tipo, cantidad, motivo);
        redirectAttributes.addFlashAttribute("successMessage", "Movimiento de stock registrado con éxito.");
        return "redirect:/movimientos";
    }
}