package com.inventario.model;

import com.inventario.exception.StockInsuficienteException;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "productos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El código SKU es obligatorio")
    @Size(max = 30, message = "El SKU no puede superar 30 caracteres")
    @Column(nullable = false, unique = true, length = 30)
    private String codigoSKU;

    @NotBlank(message = "El nombre del producto es obligatorio")
    @Size(max = 100, message = "El nombre no puede superar 100 caracteres")
    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @NotNull(message = "El precio unitario es obligatorio")
    @DecimalMin(value = "0.0", inclusive = true, message = "El precio debe ser mayor o igual a 0")
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal precioUnitario;

    @NotNull(message = "El stock actual es obligatorio")
    @Min(value = 0, message = "El stock actual no puede ser negativo")
    @Column(nullable = false)
    private Integer stockActual;

    @NotNull(message = "El stock mínimo es obligatorio")
    @Min(value = 0, message = "El stock mínimo no puede ser negativo")
    @Column(nullable = false)
    private Integer stockMinimo;

    @Builder.Default
    @Column(nullable = false)
    private Boolean activo = true;

    @NotNull(message = "Debe asignar una categoría al producto")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoria_id", nullable = false)
    private Categoria categoria;

    public void registrarIngreso(Integer cantidad) {
        if (cantidad == null || cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad ingresada debe ser mayor a 0");
        }
        this.stockActual += cantidad;
    }

    public void registrarEgreso(Integer cantidad) {
        if (cantidad == null || cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad a egresar debe ser mayor a 0");
        }
        if (this.stockActual - cantidad < 0) {
            throw new StockInsuficienteException(
                String.format("No se autoriza el egreso de %d unidades. Stock disponible: %d", cantidad, this.stockActual)
            );
        }
        this.stockActual -= cantidad;
    }

    public boolean isStockCritico() {
        return this.stockActual <= this.stockMinimo;
    }
}