package com.inventario.model;

public enum TipoMovimiento {
    INGRESO,
    EGRESO
}