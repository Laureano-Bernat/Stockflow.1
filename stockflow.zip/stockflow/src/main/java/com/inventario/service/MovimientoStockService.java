package com.inventario.service;

import com.inventario.model.MovimientoStock;
import com.inventario.model.Producto;
import com.inventario.model.TipoMovimiento;
import com.inventario.repository.MovimientoStockRepository;
import com.inventario.repository.ProductoRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MovimientoStockService {

    private final ProductoRepository productoRepository;
    private final MovimientoStockRepository movimientoRepository;

    @Transactional(readOnly = true)
    public List<MovimientoStock> obtenerHistorial() {
        return movimientoRepository.findAllByOrderByFechaHoraDesc();
    }

    @Transactional(readOnly = true)
    public List<MovimientoStock> obtenerPorProducto(Long productoId) {
        return movimientoRepository.findByProductoIdOrderByFechaHoraDesc(productoId);
    }

    @Transactional
    public MovimientoStock registrarMovimiento(Long productoId, TipoMovimiento tipo, Integer cantidad, String motivo) {
        Producto producto = productoRepository.findById(productoId)
                .orElseThrow(() -> new EntityNotFoundException("Producto no encontrado con ID: " + productoId));

        if (tipo == TipoMovimiento.EGRESO) {
            producto.registrarEgreso(cantidad);
        } else {
            producto.registrarIngreso(cantidad);
        }

        MovimientoStock movimiento = MovimientoStock.builder()
                .producto(producto)
                .tipo(tipo)
                .cantidad(cantidad)
                .motivo(motivo)
                .fechaHora(LocalDateTime.now())
                .build();

        productoRepository.save(producto);
        return movimientoRepository.save(movimiento);
    }
}