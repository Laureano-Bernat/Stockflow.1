package com.inventario.service;

import com.inventario.model.Producto;
import com.inventario.repository.ProductoRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductoService {

    private final ProductoRepository productoRepository;

    @Transactional(readOnly = true)
    public List<Producto> obtenerTodosActivos() {
        return productoRepository.findByActivoTrue();
    }

    @Transactional(readOnly = true)
    public List<Producto> filtrarProductos(String query, Long categoriaId) {
        return productoRepository.buscarPorFiltros(query, categoriaId);
    }

    @Transactional(readOnly = true)
    public List<Producto> obtenerStockCritico() {
        return productoRepository.findProductosConStockCritico();
    }

    @Transactional(readOnly = true)
    public Producto obtenerPorId(Long id) {
        return productoRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Producto no encontrado con ID: " + id));
    }

    @Transactional
    public Producto guardar(Producto producto) {
        if (producto.getId() == null && productoRepository.existsByCodigoSKU(producto.getCodigoSKU())) {
            throw new IllegalArgumentException("El código SKU " + producto.getCodigoSKU() + " ya está registrado.");
        }
        return productoRepository.save(producto);
    }

    @Transactional
    public void bajaLogica(Long id) {
        Producto producto = obtenerPorId(id);
        producto.setActivo(false);
        productoRepository.save(producto);
    }
}