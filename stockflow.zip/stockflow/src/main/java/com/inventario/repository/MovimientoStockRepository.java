package com.inventario.repository;

import com.inventario.model.MovimientoStock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovimientoStockRepository extends JpaRepository<MovimientoStock, Long> {
    List<MovimientoStock> findAllByOrderByFechaHoraDesc();
    List<MovimientoStock> findByProductoIdOrderByFechaHoraDesc(Long productoId);
}