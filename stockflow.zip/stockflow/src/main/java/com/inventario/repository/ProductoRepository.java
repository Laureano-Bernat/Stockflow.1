package com.inventario.repository;

import com.inventario.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {

    List<Producto> findByActivoTrue();

    @Query("SELECT p FROM Producto p WHERE p.activo = true AND p.stockActual <= p.stockMinimo")
    List<Producto> findProductosConStockCritico();

    @Query("SELECT p FROM Producto p WHERE p.activo = true AND " +
           "(:query IS NULL OR LOWER(p.nombre) LIKE LOWER(CONCAT('%', :query, '%')) OR LOWER(p.codigoSKU) LIKE LOWER(CONCAT('%', :query, '%'))) AND " +
           "(:categoriaId IS NULL OR p.categoria.id = :categoriaId)")
    List<Producto> buscarPorFiltros(@Param("query") String query, @Param("categoriaId") Long categoriaId);

    boolean existsByCodigoSKU(String codigoSKU);
}