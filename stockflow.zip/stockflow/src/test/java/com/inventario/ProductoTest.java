package com.inventario;

import com.inventario.exception.StockInsuficienteException;
import com.inventario.model.Producto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProductoTest {

    private Producto producto;

    @BeforeEach
    void setup() {
        producto = new Producto();
        producto.setStockActual(50);
    }

    @Test
    void testRegistrarEgreso_CasoCorrecto() {
        producto.registrarEgreso(20);
        assertEquals(30, producto.getStockActual());
    }

    @Test
    void testRegistrarEgreso_DatoInvalido_StockInsuficiente() {
        assertThrows(StockInsuficienteException.class, () -> {
            producto.registrarEgreso(60);
        });
    }

    @Test
    void testRegistrarEgreso_CasoLimite_StockQuedaEnCero() {
        producto.registrarEgreso(50);
        assertEquals(0, producto.getStockActual());
    }
}